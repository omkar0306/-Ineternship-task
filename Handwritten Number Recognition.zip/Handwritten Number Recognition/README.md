# handwritten-digits-recognition
A script that trains a model to recognize handwritten digits using the MNIST data set. Then it loads external files and uses the neural network to predict what digits they are.

Feel free to add 28x28 pixel images into the digits directory!
